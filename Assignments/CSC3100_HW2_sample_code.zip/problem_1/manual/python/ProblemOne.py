def binary_search(array, first, last, value):
    while first < last:
        middle = first + (last - first) // 2
        if array[middle][0] < value:
            first = middle + 1
        else:
            last = middle
    return first


def two_sum(array, target):
    sorted_arr = sorted([(x, x_index) for x_index, x in enumerate(array)])
    for i, (x, x_index) in enumerate(sorted_arr):
        pos = binary_search(sorted_arr, i + 1, len(sorted_arr), target - x)
        if pos != len(sorted_arr):
            y, y_index = sorted_arr[pos]
            if x + y == target:
                if x_index < y_index:
                    return x_index, y_index
                else:
                    return y_index, x_index


def main():
    _, t = map(int, input().split(' '))
    a = list(map(int, input().split(' ')))
    x_index, y_index = two_sum(a, t)
    print(f'{x_index + 1} {y_index + 1}')


main()
