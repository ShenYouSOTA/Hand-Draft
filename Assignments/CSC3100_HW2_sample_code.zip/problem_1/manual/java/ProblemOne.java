import java.util.Arrays;
import java.util.Scanner;

public class ProblemOne {
    private static class Entry implements Comparable<Entry> {
        public int value;
        public int index;

        public Entry(int value, int index) {
            this.value = value;
            this.index = index;
        }

        @Override
        public int compareTo(Entry other) {
            return Integer.compare(this.value, other.value);
        }
    }

    private static int binarySearch(Entry[] array, int first, int last, int value) {
        while (first < last) {
            int middle = first + (last - first) / 2;
            if (array[middle].value < value) {
                first = middle + 1;
            } else {
                last = middle;
            }
        }
        return first;
    }

    private static int[] twoSum(int[] array, int sum) {
        Entry[] sorted = new Entry[array.length];
        for (int i = 0; i < array.length; i++) {
            sorted[i] = new Entry(array[i], i);
        }
        Arrays.sort(sorted);
        for (int i = 0; i < sorted.length; i++) {
            int x = sorted[i].value;
            int xIndex = sorted[i].index;
            int pos = binarySearch(sorted, i + 1, sorted.length, sum - x);
            if (pos != sorted.length) {
                int y = sorted[pos].value;
                int yIndex = sorted[pos].index;
                if (x + y == sum) {
                    if (xIndex < yIndex) {
                        return new int[]{xIndex, yIndex};
                    } else {
                        return new int[]{yIndex, xIndex};
                    }
                }
            }
        }
        return new int[2];
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int t = scanner.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        int[] indices = twoSum(a, t);
        System.out.print(indices[0] + 1);
        System.out.print(' ');
        System.out.print(indices[1] + 1);
        System.out.print('\n');
        scanner.close();
    }
}
