#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

int binary_search(const std::vector<std::pair<int, int> > &array, int first, int last, int value)
{
    while (first < last) {
        int middle = first + (last - first) / 2;
        if (array[middle].first < value) {
            first = middle + 1;
        } else {
            last = middle;
        }
    }
    return first;
}

std::pair<int, int> two_sum(const std::vector<int> &array, int sum)
{
    std::vector<std::pair<int, int> > sorted(array.size());
    for (int i = 0; i < int(array.size()); ++i) {
        sorted[i] = std::make_pair(array[i], i);
    }
    std::sort(sorted.begin(), sorted.end());
    for (int i = 0; i < int(sorted.size()); ++i) {
        int x = sorted[i].first;
        int x_index = sorted[i].second;
        std::vector<std::pair<int, int> >::iterator iter = std::lower_bound(sorted.begin() + i + 1, sorted.end(), std::make_pair(sum - x, 0));
        if (iter != sorted.end()) {
            int y = iter->first;
            int y_index = iter->second;
            if (x + y == sum) {
                if (x_index < y_index) {
                    return std::make_pair(x_index, y_index);
                } else {
                    return std::make_pair(y_index, x_index);
                }
            }
        }
    }
    return std::make_pair(0, 0);
}

int main()
{
    int n;
    int t;
    std::cin >> n >> t;
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }
    std::pair<int, int> result = two_sum(a, t);
    int x_index = result.first;
    int y_index = result.second;
    std::cout << x_index + 1 << ' ' << y_index + 1 << '\n';
    return 0;
}
