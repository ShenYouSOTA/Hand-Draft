#include <cstddef>
#include <cstdint>
#include <algorithm>
#include <iostream>
#include <tuple>
#include <utility>
#include <vector>

std::size_t binary_search(const std::vector<std::tuple<std::int32_t, std::size_t>> &array, std::size_t first, std::size_t last, std::int32_t value)
{
    while (first < last) {
        auto middle = first + (last - first) / 2;
        if (std::get<0>(array[middle]) < value) {
            first = middle + 1;
        } else {
            last = middle;
        }
    }
    return first;
}

std::tuple<std::size_t, std::size_t> two_sum(const std::vector<std::int32_t> &array, std::int32_t sum)
{
    auto sorted = std::vector<std::tuple<std::int32_t, std::size_t>>(array.size());
    for (auto i = std::size_t(0); i != array.size(); ++i) {
        sorted[i] = {array[i], i};
    }
    std::sort(sorted.begin(), sorted.end());
    for (auto i = std::size_t(0); i != sorted.size(); ++i) {
        auto [x, x_index] = sorted[i];
        auto iter = std::lower_bound(sorted.begin() + std::ptrdiff_t(i) + 1, sorted.end(), std::tuple{sum - x, 0});
        if (iter != sorted.end()) {
            auto [y, y_index] = *iter;
            if (x + y == sum) {
                if (x_index < y_index) {
                    return {x_index, y_index};
                } else {
                    return {y_index, x_index};
                }
            }
        }
    }
    return {};
}

int main()
{
    auto n = std::size_t{};
    auto t = std::int32_t{};
    std::cin >> n >> t;
    auto a = std::vector<std::int32_t>(n);
    for (auto i = std::size_t(0); i != n; ++i) {
        std::cin >> a[i];
    }
    auto [x_index, y_index] = two_sum(a, t);
    std::cout << x_index + 1 << ' ' << y_index + 1 << '\n';
    return 0;
}
