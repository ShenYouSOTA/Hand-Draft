import bisect


def two_sum(array, target):
    sorted_arr = sorted([(x, x_index) for x_index, x in enumerate(array)])
    for i, (x, x_index) in enumerate(sorted_arr):
        pos = bisect.bisect_left(sorted_arr, (target - x, 0), i + 1, len(sorted_arr))
        if pos != len(array):
            y, y_index = sorted_arr[pos]
            if x + y == target:
                if x_index < y_index:
                    return x_index, y_index
                else:
                    return y_index, x_index


def main():
    _, t = map(int, input().split(' '))
    a = list(map(int, input().split(' ')))
    x_index, y_index = two_sum(a, t)
    print(f'{x_index + 1} {y_index + 1}')


main()
