def merge(input_arr, output_arr, first, middle, last):
    result = 0
    i = first
    j = middle
    k = first
    while i < middle and j < last:
        if input_arr[i] <= input_arr[j]:
            output_arr[k] = input_arr[i]
            k += 1
            i += 1
        else:
            output_arr[k] = input_arr[j]
            k += 1
            j += 1
            result += middle - i
    while i < middle:
        output_arr[k] = input_arr[i]
        k += 1
        i += 1
    while j < last:
        output_arr[k] = input_arr[j]
        k += 1
        j += 1
    return result


def inversion_number(array):
    result = 0
    auxiliary = [0] * len(array)
    swapped = False
    current_size = 1
    while current_size < len(array):
        for first in range(0, len(array), current_size * 2):
            middle = min(first + current_size, len(array))
            last = min(first + current_size * 2, len(array))
            if swapped:
                result += merge(auxiliary, array, first, middle, last)
            else:
                result += merge(array, auxiliary, first, middle, last)
        swapped = not swapped
        current_size *= 2
    return result


def main():
    _ = int(input())
    a = list(map(int, input().split(' ')))
    print(inversion_number(a))


main()
