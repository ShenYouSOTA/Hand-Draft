#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

long long merge(const std::vector<int> &input, std::vector<int> &output, int first, int middle, int last)
{
    long long result = 0;
    int i = first, j = middle;
    int k = first;
    while (i < middle && j < last) {
        if (input[i] <= input[j]) {
            output[k++] = input[i++];
        } else {
            output[k++] = input[j++];
            result += middle - i;
        }
    }
    while (i < middle) {
        output[k++] = input[i++];
    }
    while (j < last) {
        output[k++] = input[j++];
    }
    return result;
}

long long inversion_number(std::vector<int> &array)
{
    long long result = 0;
    std::vector<int> auxiliary(array.size());
    std::vector<int> *input = &array;
    std::vector<int> *output = &auxiliary;
    for (int current_size = 1; current_size < int(array.size()); current_size *= 2) {
        for (int first = 0; first < int(array.size()); first += current_size * 2) {
            int middle = std::min(first + current_size, int(array.size()));
            int last = std::min(first + current_size * 2, int(array.size()));
            result += merge(*input, *output, first, middle, last);
        }
        std::swap(input, output);
    }
    return result;
}

int main()
{
    int n;
    std::cin >> n;
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }
    std::cout << inversion_number(a) << '\n';
    return 0;
}
