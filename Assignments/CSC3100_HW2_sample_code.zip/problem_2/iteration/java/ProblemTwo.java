import java.util.Scanner;

public class ProblemTwo {
    private static long merge(int[] input, int[] output, int first, int middle, int last) {
        long result = 0;
        int i = first, j = middle;
        int k = first;
        while (i < middle && j < last) {
            if (input[i] <= input[j]) {
                output[k++] = input[i++];
            } else {
                output[k++] = input[j++];
                result += middle - i;
            }
        }
        while (i < middle) {
            output[k++] = input[i++];
        }
        while (j < last) {
            output[k++] = input[j++];
        }
        return result;
    }

    private static long inversionNumber(int[] array) {
        long result = 0;
        int[] auxiliary = new int[array.length];
        boolean swapped = false;
        for (int currentSize = 1; currentSize < array.length; currentSize *= 2) {
            for (int first = 0; first < array.length; first += currentSize * 2) {
                int middle = Math.min(first + currentSize, array.length);
                int last = Math.min(first + currentSize * 2, array.length);
                if (swapped) {
                    result += merge(auxiliary, array, first, middle, last);
                } else {
                    result += merge(array, auxiliary, first, middle, last);
                }
            }
            swapped = !swapped;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        System.out.println(inversionNumber(a));
        scanner.close();
    }
}
