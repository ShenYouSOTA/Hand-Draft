#include <cstddef>
#include <cstdint>
#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

std::uint64_t merge(const std::vector<std::int32_t> &input, std::vector<std::int32_t> &output, std::size_t first, std::size_t middle, std::size_t last)
{
    auto result = std::uint64_t(0);
    auto i = first, j = middle;
    auto k = first;
    while (i != middle && j != last) {
        if (input[i] <= input[j]) {
            output[k++] = input[i++];
        } else {
            output[k++] = input[j++];
            result += middle - i;
        }
    }
    while (i != middle) {
        output[k++] = input[i++];
    }
    while (j != last) {
        output[k++] = input[j++];
    }
    return result;
}

std::uint64_t inversion_number(std::vector<std::int32_t> &array)
{
    auto result = std::uint64_t(0);
    auto auxiliary = std::vector<std::int32_t>(array.size());
    auto input = &array;
    auto output = &auxiliary;
    for (auto current_size = std::size_t(1); current_size < array.size(); current_size *= 2) {
        for (auto first = std::size_t(0); first < array.size(); first += current_size * 2) {
            auto middle = std::min(first + current_size, array.size());
            auto last = std::min(first + current_size * 2, array.size());
            result += merge(*input, *output, first, middle, last);
        }
        std::swap(input, output);
    }
    return result;
}

int main()
{
    auto n = std::size_t{};
    std::cin >> n;
    auto a = std::vector<std::int32_t>(n);
    for (auto i = std::size_t(0); i != n; ++i) {
        std::cin >> a[i];
    }
    std::cout << inversion_number(a) << '\n';
    return 0;
}
