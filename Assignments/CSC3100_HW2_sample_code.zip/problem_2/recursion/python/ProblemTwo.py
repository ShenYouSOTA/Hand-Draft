def merge(array, first, middle, last):
    result = 0
    size = last - first
    auxiliary = [0] * size
    i = first
    j = middle
    k = 0
    while i < middle and j < last:
        if array[i] <= array[j]:
            auxiliary[k] = array[i]
            k += 1
            i += 1
        else:
            auxiliary[k] = array[j]
            k += 1
            j += 1
            result += middle - i
    while i < middle:
        auxiliary[k] = array[i]
        k += 1
        i += 1
    while j < last:
        auxiliary[k] = array[j]
        k += 1
        j += 1
    i = first
    k = 0
    while i < last:
        array[i] = auxiliary[k]
        k += 1
        i += 1
    return result


def merge_sort(array, first, last):
    size = last - first
    if size <= 1:
        return 0
    result = 0
    middle = first + size // 2
    result += merge_sort(array, first, middle)
    result += merge_sort(array, middle, last)
    result += merge(array, first, middle, last)
    return result


def inversion_number(array):
    return merge_sort(array, 0, len(array))


def main():
    _ = int(input())
    a = list(map(int, input().split(' ')))
    print(inversion_number(a))


main()
