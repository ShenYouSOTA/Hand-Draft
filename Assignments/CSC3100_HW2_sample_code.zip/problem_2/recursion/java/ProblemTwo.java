import java.util.Scanner;

public class ProblemTwo {
    private static long merge(int[] array, int first, int middle, int last) {
        long result = 0;
        int size = last - first;
        int[] auxiliary = new int[size];
        int i = first, j = middle;
        int k = 0;
        while (i < middle && j < last) {
            if (array[i] <= array[j]) {
                auxiliary[k++] = array[i++];
            } else {
                auxiliary[k++] = array[j++];
                result += middle - i;
            }
        }
        while (i < middle) {
            auxiliary[k++] = array[i++];
        }
        while (j < last) {
            auxiliary[k++] = array[j++];
        }
        i = first;
        k = 0;
        while (i < last) {
            array[i++] = auxiliary[k++];
        }
        return result;
    }

    private static long mergeSort(int[] array, int first, int last) {
        int size = last - first;
        if (size <= 1) {
            return 0;
        }
        long result = 0;
        int middle = first + size / 2;
        result += mergeSort(array, first, middle);
        result += mergeSort(array, middle, last);
        result += merge(array, first, middle, last);
        return result;
    }

    private static long inversionNumber(int[] array) {
        return mergeSort(array, 0, array.length);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        System.out.println(inversionNumber(a));
        scanner.close();
    }
}
