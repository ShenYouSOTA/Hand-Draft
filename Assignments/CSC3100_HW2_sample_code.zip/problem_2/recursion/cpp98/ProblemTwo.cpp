#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

long long merge(std::vector<int> &array, int first, int middle, int last)
{
    long long result = 0;
    int size = last - first;
    std::vector<int> auxiliary(size);
    int i = first, j = middle;
    int k = 0;
    while (i < middle && j < last) {
        if (array[i] <= array[j]) {
            auxiliary[k++] = array[i++];
        } else {
            auxiliary[k++] = array[j++];
            result += middle - i;
        }
    }
    while (i < middle) {
        auxiliary[k++] = array[i++];
    }
    while (j < last) {
        auxiliary[k++] = array[j++];
    }
    std::copy(auxiliary.begin(), auxiliary.end(), array.begin() + first);
    return result;
}

long long merge_sort(std::vector<int> &array, int first, int last)
{
    int size = last - first;
    if (size <= 1) {
        return 0;
    }
    long long result = 0;
    int middle = first + size / 2;
    result += merge_sort(array, first, middle);
    result += merge_sort(array, middle, last);
    result += merge(array, first, middle, last);
    return result;
}

long long inversion_number(std::vector<int> &array)
{
    return merge_sort(array, 0, int(array.size()));
}

int main()
{
    int n;
    std::cin >> n;
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }
    std::cout << inversion_number(a) << '\n';
    return 0;
}
