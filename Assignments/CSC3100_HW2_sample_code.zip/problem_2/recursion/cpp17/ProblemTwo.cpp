#include <cstddef>
#include <cstdint>
#include <algorithm>
#include <iostream>
#include <vector>

std::uint64_t merge(std::vector<std::int32_t> &array, std::size_t first, std::size_t middle, std::size_t last)
{
    auto result = std::uint64_t(0);
    auto size = std::size_t(last - first);
    auto auxiliary = std::vector<std::int32_t>(size);
    auto i = first, j = middle;
    auto k = std::size_t(0);
    while (i != middle && j != last) {
        if (array[i] <= array[j]) {
            auxiliary[k++] = array[i++];
        } else {
            auxiliary[k++] = array[j++];
            result += middle - i;
        }
    }
    while (i != middle) {
        auxiliary[k++] = array[i++];
    }
    while (j != last) {
        auxiliary[k++] = array[j++];
    }
    std::copy(auxiliary.begin(), auxiliary.end(), array.begin() + std::ptrdiff_t(first));
    return result;
}

std::uint64_t merge_sort(std::vector<std::int32_t> &array, std::size_t first, std::size_t last)
{
    auto size = std::size_t(last - first);
    if (size <= 1) {
        return 0;
    }
    auto result = std::uint64_t(0);
    auto middle = first + size / 2;
    result += merge_sort(array, first, middle);
    result += merge_sort(array, middle, last);
    result += merge(array, first, middle, last);
    return result;
}

std::uint64_t inversion_number(std::vector<std::int32_t> &array)
{
    return merge_sort(array, 0, array.size());
}

int main()
{
    auto n = std::size_t{};
    std::cin >> n;
    auto a = std::vector<std::int32_t>(n);
    for (auto i = std::size_t(0); i != n; ++i) {
        std::cin >> a[i];
    }
    std::cout << inversion_number(a) << '\n';
    return 0;
}
