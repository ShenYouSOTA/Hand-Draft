#include <cstddef>
#include <iostream>
#include <vector>

class LinkedList
{
public:
    struct Node
    {
        std::size_t value;
        Node *prev;
        Node *next;

        Node()
            : value{}
            , prev(nullptr)
            , next(nullptr)
        {}

        explicit Node(std::size_t value)
            : value(value)
            , prev(nullptr)
            , next(nullptr)
        {}
    };

    Node *head;

    LinkedList()
    {
        auto node = new Node{};
        node->prev = node;
        node->next = node;
        head = node;
    }

    ~LinkedList()
    {
        for (auto node = head->next; node != head;) {
            auto next = node->next;
            delete node;
            node = next;
        }
        delete head;
    }

    static Node *insert_before(Node *node, std::size_t value)
    {
        auto new_node = new Node(value);
        new_node->next = node;
        new_node->prev = node->prev;
        new_node->next->prev = new_node;
        new_node->prev->next = new_node;
        return new_node;
    }

    static Node *insert_after(Node *node, std::size_t value)
    {
        auto new_node = new Node(value);
        new_node->prev = node;
        new_node->next = node->next;
        new_node->prev->next = new_node;
        new_node->next->prev = new_node;
        return new_node;
    }

    static void erase(Node *node)
    {
        node->prev->next = node->next;
        node->next->prev = node->prev;
        delete node;
    }
};

int main()
{
    auto n = std::size_t{};
    std::cin >> n;
    auto line = LinkedList{};
    auto indices = std::vector<LinkedList::Node *>(n);
    indices[0] = LinkedList::insert_after(line.head, 0);
    for (auto i = std::size_t(1); i != n; ++i) {
        auto x = std::size_t{};
        auto p = bool{};
        std::cin >> x >> p;
        if (!p) {
            indices[i] = LinkedList::insert_before(indices[x - 1], i);
        } else {
            indices[i] = LinkedList::insert_after(indices[x - 1], i);
        }
    }
    auto m = std::size_t{};
    std::cin >> m;
    for (auto i = std::size_t(0); i != m; ++i) {
        auto y = std::size_t{};
        std::cin >> y;
        LinkedList::erase(indices[y - 1]);
    }
    for (auto node = line.head->next; node != line.head;) {
        auto value = node->value;
        node = node->next;
        std::cout << value + 1 << (node != line.head ? ' ' : '\n');
    }
    return 0;
}
