import java.util.Scanner;

public class ProblemThree {
    private static class LinkedList {
        public static class Node {
            public int value;
            public Node prev;
            public Node next;

            Node() {
                this.value = 0;
                this.prev = null;
                this.next = null;
            }

            Node(int value) {
                this.value = value;
                this.prev = null;
                this.next = null;
            }
        }

        public Node head;

        LinkedList() {
            Node node = new Node();
            node.prev = node;
            node.next = node;
            head = node;
        }

        static Node addBefore(Node node, int value) {
            Node newNode = new Node(value);
            newNode.next = node;
            newNode.prev = node.prev;
            newNode.next.prev = newNode;
            newNode.prev.next = newNode;
            return newNode;
        }

        static Node addAfter(Node node, int value) {
            Node newNode = new Node(value);
            newNode.prev = node;
            newNode.next = node.next;
            newNode.prev.next = newNode;
            newNode.next.prev = newNode;
            return newNode;
        }

        static void remove(Node node) {
            node.prev.next = node.next;
            node.next.prev = node.prev;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        LinkedList line = new LinkedList();
        LinkedList.Node[] indices = new LinkedList.Node[n];
        indices[0] = LinkedList.addAfter(line.head, 0);
        for (int i = 1; i < n; i++) {
            int x = scanner.nextInt();
            int p = scanner.nextInt();
            if (p == 0) {
                indices[i] = LinkedList.addBefore(indices[x - 1], i);
            } else {
                indices[i] = LinkedList.addAfter(indices[x - 1], i);
            }
        }
        int m = scanner.nextInt();
        for (int i = 0; i < m; i++) {
            int y = scanner.nextInt();
            LinkedList.remove(indices[y - 1]);
        }
        for (LinkedList.Node node = line.head.next; node != line.head;) {
            int value = node.value;
            node = node.next;
            System.out.print(value + 1);
            System.out.print(node != line.head ? ' ' : '\n');
        }
        scanner.close();
    }
}
