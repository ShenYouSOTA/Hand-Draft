#include <iostream>
#include <vector>

class LinkedList
{
public:
    struct Node
    {
        int value;
        Node *prev;
        Node *next;

        Node()
            : value()
            , prev(0)
            , next(0)
        {}

        explicit Node(int value)
            : value(value)
            , prev(0)
            , next(0)
        {}
    };

    Node *head;

    LinkedList()
    {
        Node *node = new Node();
        node->prev = node;
        node->next = node;
        head = node;
    }

    ~LinkedList()
    {
        for (Node *node = head->next; node < head;) {
            Node *next = node->next;
            delete node;
            node = next;
        }
        delete head;
    }

    static Node *insert_before(Node *node, int value)
    {
        Node *new_node = new Node(value);
        new_node->next = node;
        new_node->prev = node->prev;
        new_node->next->prev = new_node;
        new_node->prev->next = new_node;
        return new_node;
    }

    static Node *insert_after(Node *node, int value)
    {
        Node *new_node = new Node(value);
        new_node->prev = node;
        new_node->next = node->next;
        new_node->prev->next = new_node;
        new_node->next->prev = new_node;
        return new_node;
    }

    static void erase(Node *node)
    {
        node->prev->next = node->next;
        node->next->prev = node->prev;
        delete node;
    }
};

int main()
{
    int n;
    std::cin >> n;
    LinkedList line;
    std::vector<LinkedList::Node *> indices(n);
    indices[0] = LinkedList::insert_after(line.head, 0);
    for (int i = 1; i < n; ++i) {
        int x;
        bool p;
        std::cin >> x >> p;
        if (!p) {
            indices[i] = LinkedList::insert_before(indices[x - 1], i);
        } else {
            indices[i] = LinkedList::insert_after(indices[x - 1], i);
        }
    }
    int m;
    std::cin >> m;
    for (int i = 0; i < m; ++i) {
        int y;
        std::cin >> y;
        LinkedList::erase(indices[y - 1]);
    }
    for (LinkedList::Node *node = line.head->next; node != line.head;) {
        int value = node->value;
        node = node->next;
        std::cout << value + 1 << (node != line.head ? ' ' : '\n');
    }
    return 0;
}
