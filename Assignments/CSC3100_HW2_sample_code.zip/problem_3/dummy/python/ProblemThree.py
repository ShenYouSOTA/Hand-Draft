class LinkedList:
    class Node:
        def __init__(self, value = None):
            self.value = value
            self.prev = None
            self.next = None

    def __init__(self):
        node = LinkedList.Node()
        node.prev = node
        node.next = node
        self.head = node

    @staticmethod
    def insert_before(node, value):
        new_node = LinkedList.Node(value)
        new_node.next = node
        new_node.prev = node.prev
        new_node.next.prev = new_node
        new_node.prev.next = new_node
        return new_node

    @staticmethod
    def insert_after(node, value):
        new_node = LinkedList.Node(value)
        new_node.prev = node
        new_node.next = node.next
        new_node.prev.next = new_node
        new_node.next.prev = new_node
        return new_node

    @staticmethod
    def pop(node):
        node.prev.next = node.next
        node.next.prev = node.prev


def main():
    n = int(input())
    line = LinkedList()
    indices = [LinkedList.insert_after(line.head, 1)]
    for i in range(2, n + 1):
        x, p = map(int, input().split(' '))
        if p == 0:
            indices.append(LinkedList.insert_before(indices[x - 1], i))
        else:
            indices.append(LinkedList.insert_after(indices[x - 1], i))
    _ = int(input())
    removed = map(int, input().split(' '))
    for y in removed:
        LinkedList.pop(indices[y - 1])
    node = line.head.next
    while node is not line.head:
        value = node.value
        node = node.next
        print(value, end=' ' if node is not line.head else '\n')


main()
