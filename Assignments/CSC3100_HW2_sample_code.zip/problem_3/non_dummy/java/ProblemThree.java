import java.util.Scanner;

public class ProblemThree {
    private static class LinkedList {
        public static class Node {
            public int value;
            public Node prev;
            public Node next;

            Node() {
                this.value = 0;
                this.prev = null;
                this.next = null;
            }

            Node(int value) {
                this.value = value;
                this.prev = null;
                this.next = null;
            }
        }

        public Node head;

        LinkedList() {
            head = null;
        }

        Node addBefore(Node node, int value)
        {
            assert node != null;
            Node newNode = new Node(value);
            newNode.next = node;
            newNode.prev = node.prev;
            node.prev = newNode;
            if (newNode.prev == null) {
                head = newNode;
            } else {
                newNode.prev.next = newNode;
            }
            return newNode;
        }

        Node addAfter(Node node, int value)
        {
            Node newNode = new Node(value);
            newNode.prev = node;
            if (node == null) {
                newNode.next = head;
                head = newNode;
            } else {
                newNode.next = node.next;
                node.next = newNode;
            }
            if (newNode.next == null) {
                // pass;
            } else {
                newNode.next.prev = newNode;
            }
            return newNode;
        }

        void remove(Node node)
        {
            if (node.prev == null) {
                head = node.next;
            } else {
                node.prev.next = node.next;
            }
            if (node.next == null) {
                // pass;
            } else {
                node.next.prev = node.prev;
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        LinkedList line = new LinkedList();
        LinkedList.Node[] indices = new LinkedList.Node[n];
        indices[0] = line.addAfter(line.head, 0);
        for (int i = 1; i < n; i++) {
            int x = scanner.nextInt();
            int p = scanner.nextInt();
            if (p == 0) {
                indices[i] = line.addBefore(indices[x - 1], i);
            } else {
                indices[i] = line.addAfter(indices[x - 1], i);
            }
        }
        int m = scanner.nextInt();
        for (int i = 0; i < m; i++) {
            int y = scanner.nextInt();
            line.remove(indices[y - 1]);
        }
        for (LinkedList.Node node = line.head; node != null;) {
            int value = node.value;
            node = node.next;
            System.out.print(value + 1);
            System.out.print(node != null ? ' ' : '\n');
        }
        scanner.close();
    }
}
