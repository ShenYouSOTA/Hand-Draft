#include <cassert>
#include <cstddef>
#include <iostream>
#include <vector>

class LinkedList
{
public:
    struct Node
    {
        std::size_t value;
        Node *prev;
        Node *next;

        Node()
            : value{}
            , prev(nullptr)
            , next(nullptr)
        {}

        explicit Node(std::size_t value)
            : value(value)
            , prev(nullptr)
            , next(nullptr)
        {}
    };

    Node *head;

    LinkedList()
        : head(nullptr)
    {}

    ~LinkedList()
    {
        for (auto node = head; node != nullptr;) {
            auto next = node->next;
            delete node;
            node = next;
        }
    }

    Node *insert_before(Node *node, std::size_t value)
    {
        assert(node != nullptr);
        auto new_node = new Node(value);
        new_node->next = node;
        new_node->prev = node->prev;
        node->prev = new_node;
        if (new_node->prev == nullptr) {
            head = new_node;
        } else {
            new_node->prev->next = new_node;
        }
        return new_node;
    }

    Node *insert_after(Node *node, std::size_t value)
    {
        auto new_node = new Node(value);
        new_node->prev = node;
        if (node == nullptr) {
            new_node->next = head;
            head = new_node;
        } else {
            new_node->next = node->next;
            node->next = new_node;
        }
        if (new_node->next == nullptr) {
            // pass;
        } else {
            new_node->next->prev = new_node;
        }
        return new_node;
    }

    void erase(Node *node)
    {
        if (node->prev == nullptr) {
            head = node->next;
        } else {
            node->prev->next = node->next;
        }
        if (node->next == nullptr) {
            // pass;
        } else {
            node->next->prev = node->prev;
        }
        delete node;
    }
};

int main()
{
    auto n = std::size_t{};
    std::cin >> n;
    auto line = LinkedList{};
    auto indices = std::vector<LinkedList::Node *>(n);
    indices[0] = line.insert_after(nullptr, 0);
    for (auto i = std::size_t(1); i != n; ++i) {
        auto x = std::size_t{};
        auto p = bool{};
        std::cin >> x >> p;
        if (!p) {
            indices[i] = line.insert_before(indices[x - 1], i);
        } else {
            indices[i] = line.insert_after(indices[x - 1], i);
        }
    }
    auto m = std::size_t{};
    std::cin >> m;
    for (auto i = std::size_t(0); i != m; ++i) {
        auto y = std::size_t{};
        std::cin >> y;
        line.erase(indices[y - 1]);
    }
    for (auto node = line.head; node != nullptr;) {
        auto value = node->value;
        node = node->next;
        std::cout << value + 1 << (node != nullptr ? ' ' : '\n');
    }
    return 0;
}
