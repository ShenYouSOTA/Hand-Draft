#include <cassert>
#include <iostream>
#include <vector>

class LinkedList
{
public:
    struct Node
    {
        int value;
        Node *prev;
        Node *next;

        Node()
            : value()
            , prev(0)
            , next(0)
        {}

        explicit Node(int value)
            : value(value)
            , prev(0)
            , next(0)
        {}
    };

    Node *head;

    LinkedList()
        : head(0)
    {}

    ~LinkedList()
    {
        for (Node *node = head; node != 0;) {
            Node *next = node->next;
            delete node;
            node = next;
        }
    }

    Node *insert_before(Node *node, int value)
    {
        assert(node != 0);
        Node *new_node = new Node(value);
        new_node->next = node;
        new_node->prev = node->prev;
        node->prev = new_node;
        if (new_node->prev == 0) {
            head = new_node;
        } else {
            new_node->prev->next = new_node;
        }
        return new_node;
    }

    Node *insert_after(Node *node, int value)
    {
        Node *new_node = new Node(value);
        new_node->prev = node;
        if (node == 0) {
            new_node->next = head;
            head = new_node;
        } else {
            new_node->next = node->next;
            node->next = new_node;
        }
        if (new_node->next == 0) {
            // pass;
        } else {
            new_node->next->prev = new_node;
        }
        return new_node;
    }

    void erase(Node *node)
    {
        if (node->prev == 0) {
            head = node->next;
        } else {
            node->prev->next = node->next;
        }
        if (node->next == 0) {
            // pass;
        } else {
            node->next->prev = node->prev;
        }
        delete node;
    }
};

int main()
{
    int n;
    std::cin >> n;
    LinkedList line;
    std::vector<LinkedList::Node *> indices(n);
    indices[0] = line.insert_after(0, 0);
    for (int i = 1; i < n; ++i) {
        int x;
        bool p;
        std::cin >> x >> p;
        if (!p) {
            indices[i] = line.insert_before(indices[x - 1], i);
        } else {
            indices[i] = line.insert_after(indices[x - 1], i);
        }
    }
    int m;
    std::cin >> m;
    for (int i = 0; i < m; ++i) {
        int y;
        std::cin >> y;
        line.erase(indices[y - 1]);
    }
    for (LinkedList::Node *node = line.head; node != 0;) {
        int value = node->value;
        node = node->next;
        std::cout << value + 1 << (node != 0 ? ' ' : '\n');
    }
    return 0;
}
