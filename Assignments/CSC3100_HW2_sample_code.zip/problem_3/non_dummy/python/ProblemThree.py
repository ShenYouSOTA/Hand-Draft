class LinkedList:
    class Node:
        def __init__(self, value = None):
            self.value = value
            self.prev = None
            self.next = None

    def __init__(self):
        self.head = None

    def insert_before(self, node, value):
        assert node is not None
        new_node = LinkedList.Node(value)
        new_node.next = node
        new_node.prev = node.prev
        node.prev = new_node
        if new_node.prev is None:
            self.head = new_node
        else:
            new_node.prev.next = new_node
        return new_node

    def insert_after(self, node, value):
        new_node = LinkedList.Node(value)
        new_node.prev = node
        if node is None:
            new_node.next = self.head
            self.head = new_node
        else:
            new_node.next = node.next
            node.next = new_node
        if new_node.next is None:
            pass
        else:
            new_node.next.prev = new_node
        return new_node

    def pop(self, node):
        if node.prev is None:
            self.head = node.next
        else:
            node.prev.next = node.next
        if node.next is None:
            pass
        else:
            node.next.prev = node.prev


def main():
    n = int(input())
    line = LinkedList()
    indices = [line.insert_after(None, 1)]
    for i in range(2, n + 1):
        x, p = map(int, input().split(' '))
        if p == 0:
            indices.append(line.insert_before(indices[x - 1], i))
        else:
            indices.append(line.insert_after(indices[x - 1], i))
    _ = int(input())
    removed = map(int, input().split(' '))
    for y in removed:
        line.pop(indices[y - 1])
    node = line.head
    while node is not None:
        value = node.value
        node = node.next
        print(value, end=' ' if node is not None else '\n')


main()
