#include <iostream>
#include <list>
#include <vector>

int main()
{
    int n;
    std::cin >> n;
    std::list<int> line;
    std::vector<std::list<int>::iterator> indices(n);
    indices[0] = line.insert(line.begin(), 0);
    for (int i = 1; i < n; ++i) {
        int x;
        bool p;
        std::cin >> x >> p;
        if (!p) {
            indices[i] = line.insert(indices[x - 1], i);
        } else {
            std::list<int>::iterator iter = indices[x - 1];
            ++iter;
            indices[i] = line.insert(iter, i);
        }
    }
    int m;
    std::cin >> m;
    for (int i = 0; i < m; ++i) {
        int y;
        std::cin >> y;
        line.erase(indices[y - 1]);
    }
    for (std::list<int>::iterator iter = line.begin(); iter != line.end();) {
        int value = *iter;
        std::cout << value + 1 << (iter++ != line.end() ? " " : "\n");
    }
    return 0;
}
