#include <cstddef>
#include <iostream>
#include <iterator>
#include <list>
#include <vector>

int main()
{
    auto n = std::size_t{};
    std::cin >> n;
    auto line = std::list<std::size_t>{};
    auto indices = std::vector<std::list<std::size_t>::iterator>(n);
    indices[0] = line.emplace(line.begin(), 0);
    for (auto i = std::size_t(1); i != n; ++i) {
        auto x = std::size_t{};
        auto p = bool{};
        std::cin >> x >> p;
        if (!p) {
            indices[i] = line.emplace(indices[x - 1], i);
        } else {
            indices[i] = line.emplace(std::next(indices[x - 1]), i);
        }
    }
    auto m = std::size_t{};
    std::cin >> m;
    for (auto i = std::size_t(0); i != m; ++i) {
        auto y = std::size_t{};
        std::cin >> y;
        line.erase(indices[y - 1]);
    }
    for (auto iter = line.begin(); iter != line.end();) {
        auto value = *iter;
        std::cout << value + 1 << (iter++ != line.end() ? " " : "\n");
    }
    return 0;
}
