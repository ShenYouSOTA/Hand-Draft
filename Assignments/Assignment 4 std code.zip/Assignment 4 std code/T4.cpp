#include<cstdio>
#include<cstring>
#include<algorithm>
#define mod 1000000007
#define MN 2005
#define ll long long
#define inf 0x7fffffffffffffffll
using namespace std;
inline ll in(){
    ll x=0;bool f=0;char c;
    for (;(c=getchar())<'0'||c>'9';f=c=='-');
    for (x=c-'0';(c=getchar())>='0'&&c<='9';x=(x<<3)+(x<<1)+c-'0');
    return f?-x:x;
}

ll mp[MN][MN], x[MN], y[MN], dis[MN], c, res;
bool vis[MN];
int n;

ll prim(){
	ll res = 0;
	memset(dis, 0x3f, sizeof(dis));
	dis[1] = 0;
	for (int i = 1; i <= n; ++i){
		int cur = 0;
		for (int j = 1; j <= n; ++j){
			if ((!vis[j]) && dis[j] < dis[cur]){
				cur = j;
			}
		}

		if (!cur){
			return -1;
		}
		vis[cur] = 1; res += dis[cur];
		for (int j = 1; j <= n; ++j){
			if ((!vis[j]) && dis[j] > mp[cur][j]){
				dis[j] = mp[cur][j];
			}
		}
	}
	return res;
}

int main()
{
	n = in(); c = in();
	for (int i = 1; i <= n; ++i){
        x[i] = in(); y[i] = in();
    }

	memset(mp, 0x3f, sizeof(mp));
	for (int i = 1; i <= n; ++i){
		for (int j = 1; j <= i; ++j){
			ll d = (x[i] - x[j]) * (x[i] - x[j]) + (y[i] - y[j]) * (y[i] - y[j]);
			if (d >= c){
				mp[i][j] = mp[j][i] = d;
			}
		}
	}

	printf("%lld", prim());
    return 0;
}