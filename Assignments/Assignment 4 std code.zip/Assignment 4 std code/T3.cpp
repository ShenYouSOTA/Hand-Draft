#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define MN 5005
#define MM 100005
#define inf 0x3f3f3f3f
using namespace std;
inline int in(){
    int x=0;bool f=0;char c;
    for (;(c=getchar())<'0'||c>'9';f=c=='-');
    for (x=c-'0';(c=getchar())>='0'&&c<='9';x=(x<<3)+(x<<1)+c-'0');
    return f?-x:x;
}

struct edge{
    int to, nxt, val;
}e[MM << 1];

int h[MN], dis1[MN], dis2[MN];
int cnt, n, m, u, v, w;

inline void ins(int u,int v,int w){
    e[++cnt].to = v; e[cnt].nxt = h[u]; h[u] = cnt; e[cnt].val = w;
}

struct vtx{
    int u, d1, d2;
};

inline bool operator <(const vtx & x, const vtx & y){
    return (x.d1 == y.d1)? (x.d2 > y.d2): (x.d1 > y.d1);
}

priority_queue <vtx> q;

int dijkstra(int s, int t){
    memset(dis1, 0x3f, sizeof(dis1));
    memset(dis2, 0x3f, sizeof(dis2));
    dis1[s] = 0;
    q.push((vtx){s, 0, inf});
    while (!q.empty()){
        vtx tmp = q.top(); q.pop();
        int u = tmp.u;
        if (tmp.d1 != dis1[u] || tmp.d2 != dis2[u]){
            continue;
        }
        for (int i = h[u]; i; i = e[i].nxt){
            int v = e[i].to, w = e[i].val;
            if (dis1[v] > dis1[u] + w){
                dis2[v] = dis1[v];
                dis1[v] = dis1[u] + w;
                q.push((vtx){v, dis1[v], dis2[v]});
            }
            if (dis2[v] > dis1[u] + w && dis1[v] < dis1[u] + w){
                dis2[v] = dis1[u] + w;
                q.push((vtx){v, dis1[v], dis2[v]}); 
            }
            if (dis2[v] > dis2[u] + w){
                dis2[v] = dis2[u] + w;
                q.push((vtx){v, dis1[v], dis2[v]});
            }
        }
    }
    return dis2[t];
}

int main()
{
	n = in(); m = in();
    for (int i = 1; i <= m; ++i){
        u = in(); v = in(); w = in();
        ins(u, v, w); ins(v, u, w);
    }
    printf("%d", dijkstra(1, n));
    return 0;
}