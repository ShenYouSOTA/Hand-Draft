#include<cstdio>
#include<cstring>
#include<algorithm>
#include<unordered_map>
using namespace std;
inline int in(){
    int x=0;bool f=0;char c;
    for (;(c=getchar())<'0'||c>'9';f=c=='-');
    for (x=c-'0';(c=getchar())>='0'&&c<='9';x=(x<<3)+(x<<1)+c-'0');
    return f?-x:x;
}

int n, T, num;
unordered_map <int, bool> mp;

int main()
{
    T = in();
    while (T--){
        mp.clear();
        n = in();
        for (int i = 1; i <= n; ++i){
            num = in();
            if (!mp.count(num)){
                mp[num] = 1;
                printf("%d ", num);
            }
        }
        printf("\n");
    }
    return 0;
}