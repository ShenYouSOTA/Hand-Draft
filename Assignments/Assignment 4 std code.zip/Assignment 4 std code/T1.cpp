#include<cstdio>
#include<cstring>
#include<algorithm>
#define mod 1000000007
#define MN 1000005
using namespace std;
inline int in(){
    int x=0;bool f=0;char c;
    for (;(c=getchar())<'0'||c>'9';f=c=='-');
    for (x=c-'0';(c=getchar())>='0'&&c<='9';x=(x<<3)+(x<<1)+c-'0');
    return f?-x:x;
}

int l[MN], r[MN], w[MN], siz[MN];
int n, mx;

inline void dfs1(int u){
    siz[u] = 1;
    if (l[u] != -1){
        dfs1(l[u]);
        siz[u] += siz[l[u]];
    }
    if (r[u] != -1){
        dfs1(r[u]);
        siz[u] += siz[r[u]];
    }
}

inline bool dfs2(int u, int v){
    return ((u == -1 && v == -1) || (u != -1 && v != -1 && w[u] == w[v] && dfs2(l[u], r[v]) && dfs2(r[u], l[v])));
}

int main()
{
	n = in(); mx = 0;
	for (int i = 1; i <= n; ++i){
        w[i] = in();
    }
    for (int i = 1; i <= n; ++i){
        l[i] = in(); r[i] = in();
    }
    dfs1(1);
    for (int i = 1; i <= n; ++i){
        if (dfs2(l[i], r[i])){
            mx = max(mx, siz[i]);
        }
    }
    printf("%d", mx);
    return 0;
}